# Information about set4

## 12632 courses in total

## 12624 courses are in course-info

## 1313 courses with Reddit comments are generated into the folder courseReddit/

## 1313 courses are evaluated and ranked in score.out
